# Video.js Default Skin

A Pen created on CodePen.io. Original URL: [https://codepen.io/heff/pen/EarCt](https://codepen.io/heff/pen/EarCt).

This is the base skin of Video.js that can be modified to make custom skins.

The great thing about Video.js skins is they work in both HTML5 video AND Flash!